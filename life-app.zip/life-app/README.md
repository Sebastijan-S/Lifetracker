# Life Tracker (PWA)

Serve the `life-app` folder over HTTP to test the PWA (service worker requires secure context or localhost).

From the workspace root run:

```bash
cd "life-app"
python3 -m http.server 8000